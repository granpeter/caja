package udea.edu.co.caja.caja.Entidades;

public enum Enum_RoleName {
Admin,Operario
}
