package udea.edu.co.caja.caja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CajaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CajaApplication.class, args);
	}

}
